#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import resources.lib.undernextrap as undernextrap

if __name__ == '__main__':
    unext_af = undernextrap.UnderNexTrapAnimeFree()
    unext_af()
