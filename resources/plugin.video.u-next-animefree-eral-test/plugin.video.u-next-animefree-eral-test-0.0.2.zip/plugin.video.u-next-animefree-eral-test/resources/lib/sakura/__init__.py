# -*- coding: utf-8 -*-
# sakura
#
# Kodi用スクリプトアドオンルーター
#
from __future__ import annotations
from .script_addon_router_for_kodi import ScriptAddonRouterForKodi  # noqa:F401
